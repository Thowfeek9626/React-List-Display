import React, { useState } from 'react';
import { Typography } from '@mui/material';
import ListDisplay from './ListDisplay';
import {
  Box,
  IconButton,
} from '@mui/material';
import TableChartIcon from '@mui/icons-material/TableChart';
import ViewModuleIcon from '@mui/icons-material/ViewModule';

const Home = () => {
  const [view, setView] = useState('card');
  const handleToggle = () => {
    setView(view === 'card' ? 'table' : 'card');
  };
  return (
    <div>
      <Box display="flex" justifyContent="space-between" marginBottom="1rem">
        <Typography
          variant="h4"
          sx={{
            border: '1px solid #dee2e6',
            borderRadius: '8px',
            padding: '12px',
            backgroundColor: '#ffffff',
            color: '#495057',
            userSelect: 'none',
            cursor: 'default',
          }}
        >
          Products
        </Typography>
        <Box display="flex" alignItems="center" sx={{ marginRight: '16px' }}>
          <IconButton onClick={handleToggle} sx={{ color: '#BCCCDC', background: '#27445D', '&:hover': { color: '#27445D' }, }}>
            {view == 'card' ? <ViewModuleIcon /> : <TableChartIcon />}
          </IconButton>
        </Box>
      </Box>
      <ListDisplay view={view} path={'products'} />
    </div>
  );
};

export default Home;
