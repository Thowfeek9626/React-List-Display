import React, { useState, useEffect } from 'react';
import { Typography, Grid, Box, IconButton, Tabs, Tab } from '@mui/material';
import useFetch from '../hooks/useFetch';
import TableChartIcon from '@mui/icons-material/TableChart';
import ViewModuleIcon from '@mui/icons-material/ViewModule';
import ListDisplay from './ListDisplay';

const CategoriesPage = () => {
    const [selectedCategory, setSelectedCategory] = useState('');
    const [view, setView] = useState('card');
    const { data } = useFetch('https://fakestoreapi.com/products/categories');

    useEffect(() => {
        if (data.length > 0) setSelectedCategory(data[0]);
    }, [data]);

    return (
        <div>
            <Box display="flex" justifyContent="space-between" marginBottom="1rem">
                <Typography variant="h4" sx={{ border: '1px solid #dee2e6', borderRadius: '8px', padding: '12px', backgroundColor: '#ffffff', color: '#495057', userSelect: 'none' }}>
                    Categories
                </Typography>
                <Box display="flex" alignItems="center" sx={{ marginRight: '16px' }}>
                    <IconButton onClick={() => setView(view === 'card' ? 'table' : 'card')} sx={{ color: '#BCCCDC', background: '#27445D', '&:hover': { color: '#27445D' }, }}>
                        {view === 'card' ? <ViewModuleIcon /> : <TableChartIcon />}
                    </IconButton>
                </Box>
            </Box>
            <Grid container spacing={2}>
                <Tabs value={data.indexOf(selectedCategory)} onChange={(e, newValue) => setSelectedCategory(data[newValue])}>
                    {data.map((category) => <Tab label={category} key={category} />)}
                </Tabs>
            </Grid>
            {selectedCategory && <ListDisplay path={`products/category/${selectedCategory}`} view={view} />}
        </div>
    );
};

export default CategoriesPage;
