import {
    Box,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    TableContainer,
    Paper
} from '@mui/material';

const TableView = ({ filteredList }) => {
    return (
        <TableContainer component={Paper} sx={{ borderRadius: '12px', overflow: 'hidden', boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)' }}>
            <Table sx={{ userSelect: 'none', borderCollapse: 'separate', borderSpacing: '0' }}>
                <TableHead sx={{ backgroundColor: '#e9ecef' }}>
                    <TableRow>
                        <TableCell sx={{ fontWeight: 'bold', color: '#212529', fontSize: '1rem', padding: '16px' }}>Title</TableCell>
                        <TableCell sx={{ fontWeight: 'bold', color: '#212529', fontSize: '1rem', padding: '16px' }}>Description</TableCell>
                        <TableCell sx={{ fontWeight: 'bold', color: '#212529', fontSize: '1rem', padding: '16px' }}>Image</TableCell>
                        <TableCell sx={{ fontWeight: 'bold', color: '#212529', fontSize: '1rem', padding: '16px' }}>Price</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {filteredList.map((item, index) => (
                        <TableRow
                            key={item.id}
                            sx={{
                                backgroundColor: index % 2 === 0 ? '#f8f9fa' : 'white',
                                '&:hover': { backgroundColor: '#f1f3f5' },
                                transition: 'background-color 0.2s ease-in-out',
                            }}
                        >
                            <TableCell sx={{ padding: '16px', fontSize: '0.95rem', color: '#495057' }}>{item.title}</TableCell>
                            <TableCell sx={{ padding: '16px', fontSize: '0.95rem', color: '#495057' }}>{item.description}</TableCell>
                            <TableCell sx={{ padding: '16px' }}>
                                <Box
                                    component="img"
                                    src={item.image}
                                    alt={item.title}
                                    sx={{
                                        width: '100px',
                                        height: '100px',
                                        objectFit: 'contain',
                                        borderRadius: '8px',
                                        border: '1px solid #dee2e6',
                                    }}
                                />
                            </TableCell>
                            <TableCell sx={{ padding: '16px', fontSize: '0.95rem', color: '#495057' }}>${item.price}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

export default TableView;
