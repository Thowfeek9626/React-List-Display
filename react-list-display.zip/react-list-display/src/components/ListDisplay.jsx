import React, { useState, useMemo } from 'react';
import { Box, Typography, CircularProgress, TextField } from '@mui/material';
import useFetch from '../hooks/useFetch';
import TableView from './TableView';
import CardView from './CardView';

const ListDisplay = ({ path, view }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const { data, loading, error } = useFetch(`https://fakestoreapi.com/${path}`);

  const filteredList = useMemo(
    () => data?.filter((item) => item.title?.toLowerCase().includes(searchTerm.toLowerCase())),
    [data, searchTerm]
  );

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <Typography variant="h6" color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box>
      <TextField
        label="Search Products"
        variant="outlined"
        fullWidth
        margin="normal"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        sx={{ marginBottom: '1.5rem' }}
      />
      {view === 'card' ? <CardView filteredList={filteredList} /> : <TableView filteredList={filteredList} />}
    </Box>
  );
};

export default ListDisplay;
