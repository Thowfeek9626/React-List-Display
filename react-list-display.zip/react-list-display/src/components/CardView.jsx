import React from 'react';
import {
    Box,
    Grid,
    Card,
    CardContent,
    Typography,
} from '@mui/material';

const CardView = ({ filteredList }) => {
    return (
        <Grid container spacing={2}>
            {filteredList.map((item) => (
                <Grid item xs={12} sm={6} md={4} lg={3} key={item.id}>
                    <Card
                        sx={{
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            height: {
                                xs: '280px', // Smaller height for mobile screens
                                sm: '320px', // Medium height for tablets
                                md: '360px', // Larger height for desktops
                                lg: '400px', // Even larger height for larger screens
                            },
                            userSelect: 'none',
                            borderRadius: '12px',
                            boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
                            backgroundColor: '#ffffff',
                            '&:hover': { boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.2)' },
                            cursor: 'pointer',
                        }}
                    >
                        <CardContent
                            sx={{
                                display: 'flex',
                                flexDirection: 'column',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                height: '100%',
                                width: '100%',
                            }}
                        >
                            <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#343a40', textAlign: 'center' }}>
                                {item.title}
                            </Typography>
                            <Box
                                component="img"
                                src={item.image}
                                alt={item.title}
                                sx={{
                                    width: '100%',
                                    height: 'auto',
                                    maxHeight: '150px',
                                    objectFit: 'contain',
                                    marginTop: '8px',
                                }}
                            />
                            <Typography variant="body1" sx={{ color: '#007bff', fontWeight: 'bold', marginTop: '8px' }}>
                                ${item.price}
                            </Typography>
                        </CardContent>
                    </Card>
                </Grid>
            ))}
        </Grid>
    );
};

export default CardView;
