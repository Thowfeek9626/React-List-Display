import React from 'react';
import { AppBar, Toolbar, Typography } from '@mui/material';
import { NavLink } from 'react-router-dom';
import logo from '../images/appLogo.png';

const navLinkStyles = ({ isActive }) => ({
  color: isActive ? '#FFF' : '#D3D3D3',
  textDecoration: 'none',
  padding: '8px 16px',
  fontWeight: isActive ? 'bold' : 'normal',
});

const Navbar = () => (
  <AppBar position="static" sx={{ backgroundColor: '#497D74' }}>
    <Toolbar>
      <img src={logo} alt="Logo" style={{ height: '80px', width: 'auto', marginRight: 16 }} />
      <Typography variant="h5" sx={{ flexGrow: 1, userSelect: 'none', cursor: 'pointer' }}>
        React List Display
      </Typography>
      <NavLink to="/" style={navLinkStyles}>Products</NavLink>
      <NavLink to="/categories" style={navLinkStyles}>Categories</NavLink>
    </Toolbar>
  </AppBar>
);

export default Navbar;
